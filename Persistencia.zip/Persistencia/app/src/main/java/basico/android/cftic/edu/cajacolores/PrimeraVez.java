package basico.android.cftic.edu.cajacolores;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class PrimeraVez extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_primera_vez);


    }

    public void botonSiguiente (View vista)
    {
        EditText cajaTexto = findViewById(R.id.editText);//Me apodero de la caja llamándola cajaTexto
        String textoIntroducido = cajaTexto.getText().toString();//Creo una variable a la que le asigno el valor de la caja
        if(textoIntroducido=="")
            {
                Intent intent = new Intent(PrimeraVez.this, MainActivity.class);
                startActivity(intent);
            }
        else
            {
                Toast toast = Toast.makeText(this, "Debes introducir un nombre", Toast.LENGTH_SHORT);
                toast.show();//informo de que tiene que meter un nombre
            }

    }
}
